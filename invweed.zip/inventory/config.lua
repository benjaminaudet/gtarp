database = {
    host = "local",
    name = "name",
    username = "name", -- USERNAME HERE
    password = "pass" -- PASSWORD HERE
}
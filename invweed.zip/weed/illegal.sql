INSERT INTO `items` (`id`, `libelle`) VALUES ('1', 'Cannabis'); -- NAME + ID OF CANNABIS
INSERT INTO `items` (`id`, `libelle`) VALUES ('3', 'Cannabis Traité'); -- NAME + ID OF CANNABIS ROLLING